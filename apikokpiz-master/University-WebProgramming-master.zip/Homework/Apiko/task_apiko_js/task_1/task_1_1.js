$(document).ready(function() {
    function str_rand() {
        var result       = '';
        var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        var max_position = words.length - 1;
        for( i = 0; i < 10; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
        return result;
    }
    function str_rand15() {
        var result       = '';
        var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        var max_position = words.length - 1;
        for( i = 0; i < 15; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
        return result;
    }
    function str_rand30() {
        var result       = '';
        var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        var max_position = words.length - 1;
        for( i = 0; i < 30; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
        return result;
    }
    function str_rand50() {
        var result       = '';
        var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        var max_position = words.length - 1;
        for( i = 0; i < 50; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
        return result;
    }
    function str_rand80() {
        var result       = '';
        var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        var max_position = words.length - 1;
        for( i = 0; i < 80; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
        return result;
    }
    function str_rand100() {
        var result       = '';
        var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        var max_position = words.length - 1;
        for( i = 0; i < 100; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
        return result;
    }
    function str_rand150() {
        var result       = '';
        var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        var max_position = words.length - 1;
        for( i = 0; i < 150; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
        return result;
    }
    function str_rand200() {
        var result       = '';
        var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        var max_position = words.length - 1;
        for( i = 0; i < 200; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
        return result;
    }
    function str_rand300() {
        var result       = '';
        var words        = '0123456789qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        var max_position = words.length - 1;
        for( i = 0; i < 300; ++i ) {
            position = Math.floor ( Math.random() * max_position );
            result = result + words.substring(position, position + 1);
        }
        return result;
    }

    $('.generatePassword').click(function() {
        document.getElementById('password').setAttribute('type', 'text');
        $('#password').attr('value', str_rand());
    });
    $('.generatePassword15').click(function() {
        document.getElementById('password').setAttribute('type', 'text');
        $('#password').attr('value', str_rand15());
    });
    $('.generatePassword30').click(function() {
        document.getElementById('password').setAttribute('type', 'text');
        $('#password').attr('value', str_rand30());
    });
    $('.generatePassword50').click(function() {
        document.getElementById('password').setAttribute('type', 'text');
        $('#password').attr('value', str_rand50());
    });
    $('.generatePassword80').click(function() {
        document.getElementById('password').setAttribute('type', 'text');
        $('#password').attr('value', str_rand80());
    });
    $('.generatePassword100').click(function() {
        document.getElementById('password').setAttribute('type', 'text');
        $('#password').attr('value', str_rand100());
    });
    $('.generatePassword150').click(function() {
        document.getElementById('password').setAttribute('type', 'text');
        $('#password').attr('value', str_rand150());
    });
    $('.generatePassword200').click(function() {
        document.getElementById('password').setAttribute('type', 'text');
        $('#password').attr('value', str_rand200());
    });
    $('.generatePassword300').click(function() {
        document.getElementById('password').setAttribute('type', 'text');
        $('#password').attr('value', str_rand300());
    });
});
