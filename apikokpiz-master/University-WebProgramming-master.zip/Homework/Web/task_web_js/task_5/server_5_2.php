<?php
$img_location = array('../../../../img/img1.jpg' => 1, '../../../../img/img2.jpg' => 2, '../../../../img/img3.jpg' => 3, '../../../../img/img4.jpg' => 4);
echo json_encode($img_location);
?>
